import * as React from 'react';
import { type DimensionValue } from 'react-native';
export declare const SquircleView: React.ForwardRefExoticComponent<Omit<Readonly<Omit<Readonly<{
    onAccessibilityAction?: ((event: import("react-native").AccessibilityActionEvent) => unknown) | undefined;
    onAccessibilityTap?: (() => unknown) | undefined;
    onLayout?: ((event: import("react-native").LayoutChangeEvent) => unknown) | undefined;
    onMagicTap?: (() => unknown) | undefined;
    onAccessibilityEscape?: (() => unknown) | undefined;
}>, "onMoveShouldSetResponder" | "onMoveShouldSetResponderCapture" | "onResponderGrant" | "onResponderMove" | "onResponderReject" | "onResponderRelease" | "onResponderStart" | "onResponderEnd" | "onResponderTerminate" | "onResponderTerminationRequest" | "onStartShouldSetResponder" | "onStartShouldSetResponderCapture" | "onMouseEnter" | "onMouseLeave" | "onClick" | "onClickCapture" | "onPointerEnter" | "onPointerEnterCapture" | "onPointerLeave" | "onPointerLeaveCapture" | "onPointerMove" | "onPointerMoveCapture" | "onPointerCancel" | "onPointerCancelCapture" | "onPointerDown" | "onPointerDownCapture" | "onPointerUp" | "onPointerUpCapture" | "onPointerOver" | "onPointerOverCapture" | "onPointerOut" | "onPointerOutCapture" | "onGotPointerCapture" | "onGotPointerCaptureCapture" | "onLostPointerCapture" | "onLostPointerCaptureCapture" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onMoveShouldSetResponder?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onMoveShouldSetResponderCapture?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onResponderGrant?: ((e: import("react-native").GestureResponderEvent) => void | boolean) | undefined;
    onResponderMove?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderReject?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderRelease?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderStart?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderEnd?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderTerminate?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderTerminationRequest?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onStartShouldSetResponder?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onStartShouldSetResponderCapture?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
}>, "onMouseEnter" | "onMouseLeave" | "onClick" | "onClickCapture" | "onPointerEnter" | "onPointerEnterCapture" | "onPointerLeave" | "onPointerLeaveCapture" | "onPointerMove" | "onPointerMoveCapture" | "onPointerCancel" | "onPointerCancelCapture" | "onPointerDown" | "onPointerDownCapture" | "onPointerUp" | "onPointerUpCapture" | "onPointerOver" | "onPointerOverCapture" | "onPointerOut" | "onPointerOutCapture" | "onGotPointerCapture" | "onGotPointerCaptureCapture" | "onLostPointerCapture" | "onLostPointerCaptureCapture" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onMouseEnter?: ((event: import("react-native").MouseEvent) => void) | undefined;
    onMouseLeave?: ((event: import("react-native").MouseEvent) => void) | undefined;
}>, "onClick" | "onClickCapture" | "onPointerEnter" | "onPointerEnterCapture" | "onPointerLeave" | "onPointerLeaveCapture" | "onPointerMove" | "onPointerMoveCapture" | "onPointerCancel" | "onPointerCancelCapture" | "onPointerDown" | "onPointerDownCapture" | "onPointerUp" | "onPointerUpCapture" | "onPointerOver" | "onPointerOverCapture" | "onPointerOut" | "onPointerOutCapture" | "onGotPointerCapture" | "onGotPointerCaptureCapture" | "onLostPointerCapture" | "onLostPointerCaptureCapture" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onClick?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onClickCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerEnter?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerEnterCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerLeave?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerLeaveCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerMove?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerMoveCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerCancel?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerCancelCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerDown?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerDownCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerUp?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerUpCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOver?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOverCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOut?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOutCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onGotPointerCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onGotPointerCaptureCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onLostPointerCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onLostPointerCaptureCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
}>, "onClick" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onBlur?: ((event: import("react-native").BlurEvent) => void) | undefined;
    onBlurCapture?: ((event: import("react-native").BlurEvent) => void) | undefined;
    onFocus?: ((event: import("react-native").FocusEvent) => void) | undefined;
    onFocusCapture?: ((event: import("react-native").FocusEvent) => void) | undefined;
}>, "onClick" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onTouchCancel?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchCancelCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchEnd?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchEndCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchMove?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchMoveCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchStart?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchStartCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
}>, "onClick" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    nativeBackgroundAndroid?: import("react-native/types_generated/Libraries/Components/View/ViewPropTypes").AndroidDrawable | undefined;
    nativeForegroundAndroid?: import("react-native/types_generated/Libraries/Components/View/ViewPropTypes").AndroidDrawable | undefined;
    renderToHardwareTextureAndroid?: boolean | undefined;
    hasTVPreferredFocus?: boolean | undefined;
    nextFocusDown?: number | undefined;
    nextFocusForward?: number | undefined;
    nextFocusLeft?: number | undefined;
    nextFocusRight?: number | undefined;
    nextFocusUp?: number | undefined;
    focusable?: boolean | undefined;
    tabIndex?: 0 | -1;
    onClick?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
}>, "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    shouldRasterizeIOS?: boolean | undefined;
}>, "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<Omit<Readonly<{
    accessibilityLabelledBy?: (string | undefined) | (Array<string> | undefined);
    "aria-labelledby"?: string | undefined;
    accessibilityLiveRegion?: ("none" | "polite" | "assertive") | undefined;
    "aria-live"?: ("polite" | "assertive" | "off") | undefined;
    importantForAccessibility?: ("auto" | "yes" | "no" | "no-hide-descendants") | undefined;
    screenReaderFocusable?: boolean;
}>, "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden"> & Omit<Readonly<{
    accessibilityIgnoresInvertColors?: boolean | undefined;
    accessibilityViewIsModal?: boolean | undefined;
    accessibilityShowsLargeContentViewer?: boolean | undefined;
    accessibilityLargeContentTitle?: string | undefined;
    "aria-modal"?: boolean | undefined;
    accessibilityElementsHidden?: boolean | undefined;
    accessibilityLanguage?: string | undefined;
    accessibilityRespondsToUserInteraction?: boolean | undefined;
}>, "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden"> & {
    accessible?: boolean | undefined;
    accessibilityLabel?: string | undefined;
    accessibilityHint?: string | undefined;
    "aria-label"?: string | undefined;
    experimental_accessibilityOrder?: Array<string> | undefined;
    accessibilityRole?: import("react-native").AccessibilityRole | undefined;
    role?: import("react-native").Role | undefined;
    accessibilityState?: import("react-native").AccessibilityState | undefined;
    accessibilityValue?: import("react-native").AccessibilityValue | undefined;
    "aria-valuemax"?: import("react-native").AccessibilityValue["max"] | undefined;
    "aria-valuemin"?: import("react-native").AccessibilityValue["min"] | undefined;
    "aria-valuenow"?: import("react-native").AccessibilityValue["now"] | undefined;
    "aria-valuetext"?: import("react-native").AccessibilityValue["text"] | undefined;
    accessibilityActions?: ReadonlyArray<import("react-native/types_generated/Libraries/Components/View/ViewAccessibility").AccessibilityActionInfo> | undefined;
    "aria-busy"?: boolean | undefined;
    "aria-checked"?: (boolean | undefined) | "mixed";
    "aria-disabled"?: boolean | undefined;
    "aria-expanded"?: boolean | undefined;
    "aria-selected"?: boolean | undefined;
    "aria-hidden"?: boolean | undefined;
}>, "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    children?: React.ReactNode;
    style?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheet").ViewStyleProp | undefined;
    collapsable?: boolean | undefined;
    collapsableChildren?: boolean | undefined;
    id?: string;
    testID?: string | undefined;
    nativeID?: string | undefined;
    needsOffscreenAlphaCompositing?: boolean | undefined;
    hitSlop?: import("react-native/types_generated/Libraries/StyleSheet/EdgeInsetsPropType").EdgeInsetsOrSizeProp | undefined;
    pointerEvents?: ("auto" | "box-none" | "box-only" | "none") | undefined;
    removeClippedSubviews?: boolean | undefined;
}>, never>>, "style"> & {
    cornerSmoothing?: number;
    overflow?: "visible" | "hidden";
} & {
    style?: import("react-native").StyleProp<Readonly<Omit<Readonly<Omit<Readonly<{
        display?: "none" | "flex" | "contents";
        width?: DimensionValue;
        height?: DimensionValue;
        bottom?: DimensionValue;
        end?: DimensionValue;
        left?: DimensionValue;
        right?: DimensionValue;
        start?: DimensionValue;
        top?: DimensionValue;
        inset?: DimensionValue;
        insetBlock?: DimensionValue;
        insetBlockEnd?: DimensionValue;
        insetBlockStart?: DimensionValue;
        insetInline?: DimensionValue;
        insetInlineEnd?: DimensionValue;
        insetInlineStart?: DimensionValue;
        minWidth?: DimensionValue;
        maxWidth?: DimensionValue;
        minHeight?: DimensionValue;
        maxHeight?: DimensionValue;
        margin?: DimensionValue;
        marginBlock?: DimensionValue;
        marginBlockEnd?: DimensionValue;
        marginBlockStart?: DimensionValue;
        marginBottom?: DimensionValue;
        marginEnd?: DimensionValue;
        marginHorizontal?: DimensionValue;
        marginInline?: DimensionValue;
        marginInlineEnd?: DimensionValue;
        marginInlineStart?: DimensionValue;
        marginLeft?: DimensionValue;
        marginRight?: DimensionValue;
        marginStart?: DimensionValue;
        marginTop?: DimensionValue;
        marginVertical?: DimensionValue;
        padding?: DimensionValue;
        paddingBlock?: DimensionValue;
        paddingBlockEnd?: DimensionValue;
        paddingBlockStart?: DimensionValue;
        paddingBottom?: DimensionValue;
        paddingEnd?: DimensionValue;
        paddingHorizontal?: DimensionValue;
        paddingInline?: DimensionValue;
        paddingInlineEnd?: DimensionValue;
        paddingInlineStart?: DimensionValue;
        paddingLeft?: DimensionValue;
        paddingRight?: DimensionValue;
        paddingStart?: DimensionValue;
        paddingTop?: DimensionValue;
        paddingVertical?: DimensionValue;
        borderWidth?: number;
        borderBottomWidth?: number;
        borderEndWidth?: number;
        borderLeftWidth?: number;
        borderRightWidth?: number;
        borderStartWidth?: number;
        borderTopWidth?: number;
        position?: "absolute" | "relative" | "static";
        flexDirection?: "row" | "row-reverse" | "column" | "column-reverse";
        flexWrap?: "wrap" | "nowrap" | "wrap-reverse";
        justifyContent?: "flex-start" | "flex-end" | "center" | "space-between" | "space-around" | "space-evenly";
        alignItems?: "flex-start" | "flex-end" | "center" | "stretch" | "baseline";
        alignSelf?: "auto" | "flex-start" | "flex-end" | "center" | "stretch" | "baseline";
        alignContent?: "flex-start" | "flex-end" | "center" | "stretch" | "space-between" | "space-around" | "space-evenly";
        overflow?: "visible" | "hidden" | "scroll";
        flex?: number;
        flexGrow?: number;
        flexShrink?: number;
        flexBasis?: number | string;
        aspectRatio?: number | string;
        boxSizing?: "border-box" | "content-box";
        zIndex?: number;
        direction?: "inherit" | "ltr" | "rtl";
        rowGap?: number | string;
        columnGap?: number | string;
        gap?: number | string;
    }>, "pointerEvents" | "borderRadius" | "shadowColor" | "shadowOffset" | "shadowOpacity" | "shadowRadius" | "transform" | "transformOrigin" | "backfaceVisibility" | "backgroundColor" | "borderColor" | "borderCurve" | "borderBottomColor" | "borderEndColor" | "borderLeftColor" | "borderRightColor" | "borderStartColor" | "borderTopColor" | "borderBlockColor" | "borderBlockEndColor" | "borderBlockStartColor" | "borderBottomEndRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "borderBottomStartRadius" | "borderEndEndRadius" | "borderEndStartRadius" | "borderStartEndRadius" | "borderStartStartRadius" | "borderTopEndRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderTopStartRadius" | "borderStyle" | "borderWidth" | "borderBottomWidth" | "borderEndWidth" | "borderLeftWidth" | "borderRightWidth" | "borderStartWidth" | "borderTopWidth" | "opacity" | "outlineColor" | "outlineOffset" | "outlineStyle" | "outlineWidth" | "elevation" | "cursor" | "boxShadow" | "filter" | "mixBlendMode" | "experimental_backgroundImage" | "isolation"> & Omit<Readonly<Omit<Readonly<{
        shadowColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        shadowOffset?: Readonly<{
            width?: number;
            height?: number;
        }>;
        shadowOpacity?: number;
        shadowRadius?: number;
    }>, never> & Omit<Readonly<{}>, never>>, "pointerEvents" | "borderRadius" | "transform" | "transformOrigin" | "backfaceVisibility" | "backgroundColor" | "borderColor" | "borderCurve" | "borderBottomColor" | "borderEndColor" | "borderLeftColor" | "borderRightColor" | "borderStartColor" | "borderTopColor" | "borderBlockColor" | "borderBlockEndColor" | "borderBlockStartColor" | "borderBottomEndRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "borderBottomStartRadius" | "borderEndEndRadius" | "borderEndStartRadius" | "borderStartEndRadius" | "borderStartStartRadius" | "borderTopEndRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderTopStartRadius" | "borderStyle" | "borderWidth" | "borderBottomWidth" | "borderEndWidth" | "borderLeftWidth" | "borderRightWidth" | "borderStartWidth" | "borderTopWidth" | "opacity" | "outlineColor" | "outlineOffset" | "outlineStyle" | "outlineWidth" | "elevation" | "cursor" | "boxShadow" | "filter" | "mixBlendMode" | "experimental_backgroundImage" | "isolation"> & Omit<Readonly<{
        transform?: ReadonlyArray<Readonly<import("react-native/types_generated/Libraries/StyleSheet/private/_TransformStyle").MaximumOneOf<import("react-native/types_generated/Libraries/StyleSheet/private/_TransformStyle").MergeUnion<{
            readonly perspective: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotate: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotateX: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotateY: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotateZ: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly scale: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly scaleX: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly scaleY: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly translateX: number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly translateY: number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly translate: [number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node, number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node] | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly skewX: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly skewY: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly matrix: ReadonlyArray<number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node> | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        }>>>> | string;
        transformOrigin?: [string | number, string | number, string | number] | string;
    }>, "pointerEvents" | "borderRadius" | "backfaceVisibility" | "backgroundColor" | "borderColor" | "borderCurve" | "borderBottomColor" | "borderEndColor" | "borderLeftColor" | "borderRightColor" | "borderStartColor" | "borderTopColor" | "borderBlockColor" | "borderBlockEndColor" | "borderBlockStartColor" | "borderBottomEndRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "borderBottomStartRadius" | "borderEndEndRadius" | "borderEndStartRadius" | "borderStartEndRadius" | "borderStartStartRadius" | "borderTopEndRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderTopStartRadius" | "borderStyle" | "borderWidth" | "borderBottomWidth" | "borderEndWidth" | "borderLeftWidth" | "borderRightWidth" | "borderStartWidth" | "borderTopWidth" | "opacity" | "outlineColor" | "outlineOffset" | "outlineStyle" | "outlineWidth" | "elevation" | "cursor" | "boxShadow" | "filter" | "mixBlendMode" | "experimental_backgroundImage" | "isolation"> & Omit<Readonly<{
        backfaceVisibility?: "visible" | "hidden";
        backgroundColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderCurve?: "circular" | "continuous";
        borderBottomColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderEndColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderLeftColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderRightColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderStartColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderTopColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderBlockColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderBlockEndColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderBlockStartColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderRadius?: number | string;
        borderBottomEndRadius?: number | string;
        borderBottomLeftRadius?: number | string;
        borderBottomRightRadius?: number | string;
        borderBottomStartRadius?: number | string;
        borderEndEndRadius?: number | string;
        borderEndStartRadius?: number | string;
        borderStartEndRadius?: number | string;
        borderStartStartRadius?: number | string;
        borderTopEndRadius?: number | string;
        borderTopLeftRadius?: number | string;
        borderTopRightRadius?: number | string;
        borderTopStartRadius?: number | string;
        borderStyle?: "solid" | "dotted" | "dashed";
        borderWidth?: number;
        borderBottomWidth?: number;
        borderEndWidth?: number;
        borderLeftWidth?: number;
        borderRightWidth?: number;
        borderStartWidth?: number;
        borderTopWidth?: number;
        opacity?: number;
        outlineColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        outlineOffset?: number;
        outlineStyle?: "solid" | "dotted" | "dashed";
        outlineWidth?: number;
        elevation?: number;
        pointerEvents?: "auto" | "none" | "box-none" | "box-only";
        cursor?: import("react-native").CursorValue;
        boxShadow?: ReadonlyArray<import("react-native").BoxShadowValue> | string;
        filter?: ReadonlyArray<import("react-native").FilterFunction> | string;
        mixBlendMode?: "color" | "normal" | "multiply" | "screen" | "overlay" | "darken" | "lighten" | "color-dodge" | "color-burn" | "hard-light" | "soft-light" | "difference" | "exclusion" | "hue" | "saturation" | "luminosity";
        experimental_backgroundImage?: ReadonlyArray<import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").BackgroundImageValue> | string;
        isolation?: "auto" | "isolate";
    }>, never>>, never> & Omit<Readonly<{}>, never>>> | undefined;
} & React.RefAttributes<(props: Omit<import("react-native").ViewProps, keyof {
    ref?: React.Ref<React.ComponentRef<typeof import("react-native/types_generated/Libraries/Components/View/ViewNativeComponent").default>>;
}> & {
    ref?: React.Ref<React.ComponentRef<typeof import("react-native/types_generated/Libraries/Components/View/ViewNativeComponent").default>>;
}) => React.ReactNode>>;
export declare const SquircleButton: React.ForwardRefExoticComponent<Omit<Readonly<Omit<Omit<Readonly<Omit<Readonly<{
    onAccessibilityAction?: ((event: import("react-native").AccessibilityActionEvent) => unknown) | undefined;
    onAccessibilityTap?: (() => unknown) | undefined;
    onLayout?: ((event: import("react-native").LayoutChangeEvent) => unknown) | undefined;
    onMagicTap?: (() => unknown) | undefined;
    onAccessibilityEscape?: (() => unknown) | undefined;
}>, "onMoveShouldSetResponder" | "onMoveShouldSetResponderCapture" | "onResponderGrant" | "onResponderMove" | "onResponderReject" | "onResponderRelease" | "onResponderStart" | "onResponderEnd" | "onResponderTerminate" | "onResponderTerminationRequest" | "onStartShouldSetResponder" | "onStartShouldSetResponderCapture" | "onMouseEnter" | "onMouseLeave" | "onClick" | "onClickCapture" | "onPointerEnter" | "onPointerEnterCapture" | "onPointerLeave" | "onPointerLeaveCapture" | "onPointerMove" | "onPointerMoveCapture" | "onPointerCancel" | "onPointerCancelCapture" | "onPointerDown" | "onPointerDownCapture" | "onPointerUp" | "onPointerUpCapture" | "onPointerOver" | "onPointerOverCapture" | "onPointerOut" | "onPointerOutCapture" | "onGotPointerCapture" | "onGotPointerCaptureCapture" | "onLostPointerCapture" | "onLostPointerCaptureCapture" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onMoveShouldSetResponder?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onMoveShouldSetResponderCapture?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onResponderGrant?: ((e: import("react-native").GestureResponderEvent) => void | boolean) | undefined;
    onResponderMove?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderReject?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderRelease?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderStart?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderEnd?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderTerminate?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onResponderTerminationRequest?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onStartShouldSetResponder?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
    onStartShouldSetResponderCapture?: ((e: import("react-native").GestureResponderEvent) => boolean) | undefined;
}>, "onMouseEnter" | "onMouseLeave" | "onClick" | "onClickCapture" | "onPointerEnter" | "onPointerEnterCapture" | "onPointerLeave" | "onPointerLeaveCapture" | "onPointerMove" | "onPointerMoveCapture" | "onPointerCancel" | "onPointerCancelCapture" | "onPointerDown" | "onPointerDownCapture" | "onPointerUp" | "onPointerUpCapture" | "onPointerOver" | "onPointerOverCapture" | "onPointerOut" | "onPointerOutCapture" | "onGotPointerCapture" | "onGotPointerCaptureCapture" | "onLostPointerCapture" | "onLostPointerCaptureCapture" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onMouseEnter?: ((event: import("react-native").MouseEvent) => void) | undefined;
    onMouseLeave?: ((event: import("react-native").MouseEvent) => void) | undefined;
}>, "onClick" | "onClickCapture" | "onPointerEnter" | "onPointerEnterCapture" | "onPointerLeave" | "onPointerLeaveCapture" | "onPointerMove" | "onPointerMoveCapture" | "onPointerCancel" | "onPointerCancelCapture" | "onPointerDown" | "onPointerDownCapture" | "onPointerUp" | "onPointerUpCapture" | "onPointerOver" | "onPointerOverCapture" | "onPointerOut" | "onPointerOutCapture" | "onGotPointerCapture" | "onGotPointerCaptureCapture" | "onLostPointerCapture" | "onLostPointerCaptureCapture" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onClick?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onClickCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerEnter?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerEnterCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerLeave?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerLeaveCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerMove?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerMoveCapture?: ((event: import("react-native").PointerEvent) => void) | undefined;
    onPointerCancel?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerCancelCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerDown?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerDownCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerUp?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerUpCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOver?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOverCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOut?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onPointerOutCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onGotPointerCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onGotPointerCaptureCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onLostPointerCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
    onLostPointerCaptureCapture?: ((e: import("react-native").PointerEvent) => void) | undefined;
}>, "onClick" | "onBlur" | "onBlurCapture" | "onFocus" | "onFocusCapture" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onBlur?: ((event: import("react-native").BlurEvent) => void) | undefined;
    onBlurCapture?: ((event: import("react-native").BlurEvent) => void) | undefined;
    onFocus?: ((event: import("react-native").FocusEvent) => void) | undefined;
    onFocusCapture?: ((event: import("react-native").FocusEvent) => void) | undefined;
}>, "onClick" | "onTouchCancel" | "onTouchCancelCapture" | "onTouchEnd" | "onTouchEndCapture" | "onTouchMove" | "onTouchMoveCapture" | "onTouchStart" | "onTouchStartCapture" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    onTouchCancel?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchCancelCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchEnd?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchEndCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchMove?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchMoveCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchStart?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
    onTouchStartCapture?: ((e: import("react-native").GestureResponderEvent) => void) | undefined;
}>, "onClick" | "nativeBackgroundAndroid" | "nativeForegroundAndroid" | "renderToHardwareTextureAndroid" | "hasTVPreferredFocus" | "nextFocusDown" | "nextFocusForward" | "nextFocusLeft" | "nextFocusRight" | "nextFocusUp" | "focusable" | "tabIndex" | "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    nativeBackgroundAndroid?: import("react-native/types_generated/Libraries/Components/View/ViewPropTypes").AndroidDrawable | undefined;
    nativeForegroundAndroid?: import("react-native/types_generated/Libraries/Components/View/ViewPropTypes").AndroidDrawable | undefined;
    renderToHardwareTextureAndroid?: boolean | undefined;
    hasTVPreferredFocus?: boolean | undefined;
    nextFocusDown?: number | undefined;
    nextFocusForward?: number | undefined;
    nextFocusLeft?: number | undefined;
    nextFocusRight?: number | undefined;
    nextFocusUp?: number | undefined;
    focusable?: boolean | undefined;
    tabIndex?: 0 | -1;
    onClick?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
}>, "shouldRasterizeIOS" | "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    shouldRasterizeIOS?: boolean | undefined;
}>, "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden" | "accessibilityLabelledBy" | "aria-labelledby" | "accessibilityLiveRegion" | "aria-live" | "importantForAccessibility" | "screenReaderFocusable" | "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<Omit<Readonly<{
    accessibilityLabelledBy?: (string | undefined) | (Array<string> | undefined);
    "aria-labelledby"?: string | undefined;
    accessibilityLiveRegion?: ("none" | "polite" | "assertive") | undefined;
    "aria-live"?: ("polite" | "assertive" | "off") | undefined;
    importantForAccessibility?: ("auto" | "yes" | "no" | "no-hide-descendants") | undefined;
    screenReaderFocusable?: boolean;
}>, "accessibilityIgnoresInvertColors" | "accessibilityViewIsModal" | "accessibilityShowsLargeContentViewer" | "accessibilityLargeContentTitle" | "aria-modal" | "accessibilityElementsHidden" | "accessibilityLanguage" | "accessibilityRespondsToUserInteraction" | "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden"> & Omit<Readonly<{
    accessibilityIgnoresInvertColors?: boolean | undefined;
    accessibilityViewIsModal?: boolean | undefined;
    accessibilityShowsLargeContentViewer?: boolean | undefined;
    accessibilityLargeContentTitle?: string | undefined;
    "aria-modal"?: boolean | undefined;
    accessibilityElementsHidden?: boolean | undefined;
    accessibilityLanguage?: string | undefined;
    accessibilityRespondsToUserInteraction?: boolean | undefined;
}>, "accessible" | "accessibilityLabel" | "accessibilityHint" | "aria-label" | "experimental_accessibilityOrder" | "accessibilityRole" | "role" | "accessibilityState" | "accessibilityValue" | "aria-valuemax" | "aria-valuemin" | "aria-valuenow" | "aria-valuetext" | "accessibilityActions" | "aria-busy" | "aria-checked" | "aria-disabled" | "aria-expanded" | "aria-selected" | "aria-hidden"> & {
    accessible?: boolean | undefined;
    accessibilityLabel?: string | undefined;
    accessibilityHint?: string | undefined;
    "aria-label"?: string | undefined;
    experimental_accessibilityOrder?: Array<string> | undefined;
    accessibilityRole?: import("react-native").AccessibilityRole | undefined;
    role?: import("react-native").Role | undefined;
    accessibilityState?: import("react-native").AccessibilityState | undefined;
    accessibilityValue?: import("react-native").AccessibilityValue | undefined;
    "aria-valuemax"?: import("react-native").AccessibilityValue["max"] | undefined;
    "aria-valuemin"?: import("react-native").AccessibilityValue["min"] | undefined;
    "aria-valuenow"?: import("react-native").AccessibilityValue["now"] | undefined;
    "aria-valuetext"?: import("react-native").AccessibilityValue["text"] | undefined;
    accessibilityActions?: ReadonlyArray<import("react-native/types_generated/Libraries/Components/View/ViewAccessibility").AccessibilityActionInfo> | undefined;
    "aria-busy"?: boolean | undefined;
    "aria-checked"?: (boolean | undefined) | "mixed";
    "aria-disabled"?: boolean | undefined;
    "aria-expanded"?: boolean | undefined;
    "aria-selected"?: boolean | undefined;
    "aria-hidden"?: boolean | undefined;
}>, "children" | "style" | "collapsable" | "collapsableChildren" | "id" | "testID" | "nativeID" | "needsOffscreenAlphaCompositing" | "hitSlop" | "pointerEvents" | "removeClippedSubviews"> & Omit<Readonly<{
    children?: React.ReactNode;
    style?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheet").ViewStyleProp | undefined;
    collapsable?: boolean | undefined;
    collapsableChildren?: boolean | undefined;
    id?: string;
    testID?: string | undefined;
    nativeID?: string | undefined;
    needsOffscreenAlphaCompositing?: boolean | undefined;
    hitSlop?: import("react-native/types_generated/Libraries/StyleSheet/EdgeInsetsPropType").EdgeInsetsOrSizeProp | undefined;
    pointerEvents?: ("auto" | "box-none" | "box-only" | "none") | undefined;
    removeClippedSubviews?: boolean | undefined;
}>, never>>, "onMouseEnter" | "onMouseLeave">, "children" | "style" | "testID" | "hitSlop" | "onLayout" | "cancelable" | "delayHoverIn" | "delayHoverOut" | "delayLongPress" | "disabled" | "pressRetentionOffset" | "onHoverIn" | "onHoverOut" | "onLongPress" | "onPress" | "onPressIn" | "onPressMove" | "onPressOut" | "android_disableSound" | "android_ripple" | "testOnly_pressed" | "unstable_pressDelay"> & Omit<Readonly<{
    cancelable?: boolean | undefined;
    children?: React.ReactNode | ((state: import("react-native").PressableStateCallbackType) => React.ReactNode);
    delayHoverIn?: number | undefined;
    delayHoverOut?: number | undefined;
    delayLongPress?: number | undefined;
    disabled?: boolean | undefined;
    hitSlop?: import("react-native/types_generated/Libraries/StyleSheet/Rect").RectOrSize | undefined;
    pressRetentionOffset?: import("react-native/types_generated/Libraries/StyleSheet/Rect").RectOrSize | undefined;
    onLayout?: ((event: import("react-native").LayoutChangeEvent) => unknown) | undefined;
    onHoverIn?: ((event: import("react-native").MouseEvent) => unknown) | undefined;
    onHoverOut?: ((event: import("react-native").MouseEvent) => unknown) | undefined;
    onLongPress?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
    onPress?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
    onPressIn?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
    onPressMove?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
    onPressOut?: ((event: import("react-native").GestureResponderEvent) => unknown) | undefined;
    style?: (import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ViewStyleProp_Internal | undefined) | ((state: import("react-native").PressableStateCallbackType) => import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ViewStyleProp_Internal | undefined);
    testID?: string | undefined;
    android_disableSound?: boolean | undefined;
    android_ripple?: import("react-native").PressableAndroidRippleConfig | undefined;
    testOnly_pressed?: boolean | undefined;
    unstable_pressDelay?: number | undefined;
}>, never>>, "style"> & {
    cornerSmoothing?: number;
    overflow?: "visible" | "hidden";
} & {
    style?: import("react-native").StyleProp<Readonly<Omit<Readonly<Omit<Readonly<{
        display?: "none" | "flex" | "contents";
        width?: DimensionValue;
        height?: DimensionValue;
        bottom?: DimensionValue;
        end?: DimensionValue;
        left?: DimensionValue;
        right?: DimensionValue;
        start?: DimensionValue;
        top?: DimensionValue;
        inset?: DimensionValue;
        insetBlock?: DimensionValue;
        insetBlockEnd?: DimensionValue;
        insetBlockStart?: DimensionValue;
        insetInline?: DimensionValue;
        insetInlineEnd?: DimensionValue;
        insetInlineStart?: DimensionValue;
        minWidth?: DimensionValue;
        maxWidth?: DimensionValue;
        minHeight?: DimensionValue;
        maxHeight?: DimensionValue;
        margin?: DimensionValue;
        marginBlock?: DimensionValue;
        marginBlockEnd?: DimensionValue;
        marginBlockStart?: DimensionValue;
        marginBottom?: DimensionValue;
        marginEnd?: DimensionValue;
        marginHorizontal?: DimensionValue;
        marginInline?: DimensionValue;
        marginInlineEnd?: DimensionValue;
        marginInlineStart?: DimensionValue;
        marginLeft?: DimensionValue;
        marginRight?: DimensionValue;
        marginStart?: DimensionValue;
        marginTop?: DimensionValue;
        marginVertical?: DimensionValue;
        padding?: DimensionValue;
        paddingBlock?: DimensionValue;
        paddingBlockEnd?: DimensionValue;
        paddingBlockStart?: DimensionValue;
        paddingBottom?: DimensionValue;
        paddingEnd?: DimensionValue;
        paddingHorizontal?: DimensionValue;
        paddingInline?: DimensionValue;
        paddingInlineEnd?: DimensionValue;
        paddingInlineStart?: DimensionValue;
        paddingLeft?: DimensionValue;
        paddingRight?: DimensionValue;
        paddingStart?: DimensionValue;
        paddingTop?: DimensionValue;
        paddingVertical?: DimensionValue;
        borderWidth?: number;
        borderBottomWidth?: number;
        borderEndWidth?: number;
        borderLeftWidth?: number;
        borderRightWidth?: number;
        borderStartWidth?: number;
        borderTopWidth?: number;
        position?: "absolute" | "relative" | "static";
        flexDirection?: "row" | "row-reverse" | "column" | "column-reverse";
        flexWrap?: "wrap" | "nowrap" | "wrap-reverse";
        justifyContent?: "flex-start" | "flex-end" | "center" | "space-between" | "space-around" | "space-evenly";
        alignItems?: "flex-start" | "flex-end" | "center" | "stretch" | "baseline";
        alignSelf?: "auto" | "flex-start" | "flex-end" | "center" | "stretch" | "baseline";
        alignContent?: "flex-start" | "flex-end" | "center" | "stretch" | "space-between" | "space-around" | "space-evenly";
        overflow?: "visible" | "hidden" | "scroll";
        flex?: number;
        flexGrow?: number;
        flexShrink?: number;
        flexBasis?: number | string;
        aspectRatio?: number | string;
        boxSizing?: "border-box" | "content-box";
        zIndex?: number;
        direction?: "inherit" | "ltr" | "rtl";
        rowGap?: number | string;
        columnGap?: number | string;
        gap?: number | string;
    }>, "pointerEvents" | "borderRadius" | "shadowColor" | "shadowOffset" | "shadowOpacity" | "shadowRadius" | "transform" | "transformOrigin" | "backfaceVisibility" | "backgroundColor" | "borderColor" | "borderCurve" | "borderBottomColor" | "borderEndColor" | "borderLeftColor" | "borderRightColor" | "borderStartColor" | "borderTopColor" | "borderBlockColor" | "borderBlockEndColor" | "borderBlockStartColor" | "borderBottomEndRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "borderBottomStartRadius" | "borderEndEndRadius" | "borderEndStartRadius" | "borderStartEndRadius" | "borderStartStartRadius" | "borderTopEndRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderTopStartRadius" | "borderStyle" | "borderWidth" | "borderBottomWidth" | "borderEndWidth" | "borderLeftWidth" | "borderRightWidth" | "borderStartWidth" | "borderTopWidth" | "opacity" | "outlineColor" | "outlineOffset" | "outlineStyle" | "outlineWidth" | "elevation" | "cursor" | "boxShadow" | "filter" | "mixBlendMode" | "experimental_backgroundImage" | "isolation"> & Omit<Readonly<Omit<Readonly<{
        shadowColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        shadowOffset?: Readonly<{
            width?: number;
            height?: number;
        }>;
        shadowOpacity?: number;
        shadowRadius?: number;
    }>, never> & Omit<Readonly<{}>, never>>, "pointerEvents" | "borderRadius" | "transform" | "transformOrigin" | "backfaceVisibility" | "backgroundColor" | "borderColor" | "borderCurve" | "borderBottomColor" | "borderEndColor" | "borderLeftColor" | "borderRightColor" | "borderStartColor" | "borderTopColor" | "borderBlockColor" | "borderBlockEndColor" | "borderBlockStartColor" | "borderBottomEndRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "borderBottomStartRadius" | "borderEndEndRadius" | "borderEndStartRadius" | "borderStartEndRadius" | "borderStartStartRadius" | "borderTopEndRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderTopStartRadius" | "borderStyle" | "borderWidth" | "borderBottomWidth" | "borderEndWidth" | "borderLeftWidth" | "borderRightWidth" | "borderStartWidth" | "borderTopWidth" | "opacity" | "outlineColor" | "outlineOffset" | "outlineStyle" | "outlineWidth" | "elevation" | "cursor" | "boxShadow" | "filter" | "mixBlendMode" | "experimental_backgroundImage" | "isolation"> & Omit<Readonly<{
        transform?: ReadonlyArray<Readonly<import("react-native/types_generated/Libraries/StyleSheet/private/_TransformStyle").MaximumOneOf<import("react-native/types_generated/Libraries/StyleSheet/private/_TransformStyle").MergeUnion<{
            readonly perspective: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotate: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotateX: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotateY: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly rotateZ: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly scale: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly scaleX: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly scaleY: number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly translateX: number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly translateY: number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly translate: [number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node, number | string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node] | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly skewX: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly skewY: string | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        } | {
            readonly matrix: ReadonlyArray<number | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node> | import("react-native/types_generated/Libraries/Animated/AnimatedExports").Node;
        }>>>> | string;
        transformOrigin?: [string | number, string | number, string | number] | string;
    }>, "pointerEvents" | "borderRadius" | "backfaceVisibility" | "backgroundColor" | "borderColor" | "borderCurve" | "borderBottomColor" | "borderEndColor" | "borderLeftColor" | "borderRightColor" | "borderStartColor" | "borderTopColor" | "borderBlockColor" | "borderBlockEndColor" | "borderBlockStartColor" | "borderBottomEndRadius" | "borderBottomLeftRadius" | "borderBottomRightRadius" | "borderBottomStartRadius" | "borderEndEndRadius" | "borderEndStartRadius" | "borderStartEndRadius" | "borderStartStartRadius" | "borderTopEndRadius" | "borderTopLeftRadius" | "borderTopRightRadius" | "borderTopStartRadius" | "borderStyle" | "borderWidth" | "borderBottomWidth" | "borderEndWidth" | "borderLeftWidth" | "borderRightWidth" | "borderStartWidth" | "borderTopWidth" | "opacity" | "outlineColor" | "outlineOffset" | "outlineStyle" | "outlineWidth" | "elevation" | "cursor" | "boxShadow" | "filter" | "mixBlendMode" | "experimental_backgroundImage" | "isolation"> & Omit<Readonly<{
        backfaceVisibility?: "visible" | "hidden";
        backgroundColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderCurve?: "circular" | "continuous";
        borderBottomColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderEndColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderLeftColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderRightColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderStartColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderTopColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderBlockColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderBlockEndColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderBlockStartColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        borderRadius?: number | string;
        borderBottomEndRadius?: number | string;
        borderBottomLeftRadius?: number | string;
        borderBottomRightRadius?: number | string;
        borderBottomStartRadius?: number | string;
        borderEndEndRadius?: number | string;
        borderEndStartRadius?: number | string;
        borderStartEndRadius?: number | string;
        borderStartStartRadius?: number | string;
        borderTopEndRadius?: number | string;
        borderTopLeftRadius?: number | string;
        borderTopRightRadius?: number | string;
        borderTopStartRadius?: number | string;
        borderStyle?: "solid" | "dotted" | "dashed";
        borderWidth?: number;
        borderBottomWidth?: number;
        borderEndWidth?: number;
        borderLeftWidth?: number;
        borderRightWidth?: number;
        borderStartWidth?: number;
        borderTopWidth?: number;
        opacity?: number;
        outlineColor?: import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").____ColorValue_Internal;
        outlineOffset?: number;
        outlineStyle?: "solid" | "dotted" | "dashed";
        outlineWidth?: number;
        elevation?: number;
        pointerEvents?: "auto" | "none" | "box-none" | "box-only";
        cursor?: import("react-native").CursorValue;
        boxShadow?: ReadonlyArray<import("react-native").BoxShadowValue> | string;
        filter?: ReadonlyArray<import("react-native").FilterFunction> | string;
        mixBlendMode?: "color" | "normal" | "multiply" | "screen" | "overlay" | "darken" | "lighten" | "color-dodge" | "color-burn" | "hard-light" | "soft-light" | "difference" | "exclusion" | "hue" | "saturation" | "luminosity";
        experimental_backgroundImage?: ReadonlyArray<import("react-native/types_generated/Libraries/StyleSheet/StyleSheetTypes").BackgroundImageValue> | string;
        isolation?: "auto" | "isolate";
    }>, never>>, never> & Omit<Readonly<{}>, never>>> | undefined;
    activeOpacity?: number;
} & React.RefAttributes<(props: Omit<import("react-native").ViewProps, keyof {
    ref?: React.Ref<React.ComponentRef<typeof import("react-native/types_generated/Libraries/Components/View/ViewNativeComponent").default>>;
}> & {
    ref?: React.Ref<React.ComponentRef<typeof import("react-native/types_generated/Libraries/Components/View/ViewNativeComponent").default>>;
}) => React.ReactNode>>;
//# sourceMappingURL=ResquircleView.d.ts.map