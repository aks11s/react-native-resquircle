type ShadowSpec = {
    x: number;
    y: number;
    blur: number;
    spread?: number;
    /**
     * Supported formats:
     * - `#RGB`, `#RRGGBB`, `#RRGGBBAA` (note: `RRGGBBAA`, *not* `AARRGGBB`)
     * - `rgb(r,g,b)`, `rgba(r,g,b,a)`
     * - `transparent`
     */
    color: string;
    /**
     * 0..100 (percent)
     */
    opacity: number;
};
export declare const buildBoxShadow: (shadows: ShadowSpec[]) => string;
export {};
//# sourceMappingURL=buildBoxShadow.d.ts.map