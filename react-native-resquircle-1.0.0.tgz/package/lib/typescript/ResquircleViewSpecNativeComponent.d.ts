import { type ColorValue, type ViewProps } from 'react-native';
import type { Float } from './CodegenTypes';
export interface NativeResquircleViewProps extends ViewProps {
    squircleBackgroundColor?: ColorValue;
    squircleBorderColor?: ColorValue;
    squircleBorderWidth?: Float;
    borderRadius?: Float;
    squircleTopLeftRadius?: Float;
    squircleTopRightRadius?: Float;
    squircleBottomRightRadius?: Float;
    squircleBottomLeftRadius?: Float;
    cornerSmoothing?: Float;
    squircleBoxShadow?: string;
    clipContent?: boolean;
    squircleOutlineColor?: ColorValue;
    squircleOutlineWidth?: Float;
    squircleOutlineOffset?: Float;
    squircleOutlineStyle?: string;
    color?: ColorValue;
}
declare const _default: import("react-native/types_generated/Libraries/Utilities/codegenNativeComponent").NativeComponentType<NativeResquircleViewProps>;
export default _default;
//# sourceMappingURL=ResquircleViewSpecNativeComponent.d.ts.map