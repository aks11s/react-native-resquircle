/**
 * Runtime entry. Uses require() so we only load the spec when cache is empty —
 * avoids "Tried to register two views with the same name" on Fast Refresh / branch switch.
 * Spec: ResquircleViewSpecNativeComponent has codegenNativeComponent<Props>.
 */
import type { NativeResquircleViewProps } from './ResquircleViewSpecNativeComponent';
import type { HostComponent } from 'react-native';
export type { NativeResquircleViewProps };
declare const _default: HostComponent<NativeResquircleViewProps>;
export default _default;
//# sourceMappingURL=ResquircleViewNativeComponent.d.ts.map