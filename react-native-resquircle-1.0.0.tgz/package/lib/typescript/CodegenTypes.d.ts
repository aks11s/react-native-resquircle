export type Float = number;
export type Double = number;
export type Int32 = number;
export type WithDefault<T, _D> = T;
//# sourceMappingURL=CodegenTypes.d.ts.map